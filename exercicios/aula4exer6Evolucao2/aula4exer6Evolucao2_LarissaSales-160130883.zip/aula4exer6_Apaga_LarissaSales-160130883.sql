-- --------     Aula4Exer6Evolucao2 ------------
-- 
--                    SCRIPT DE CRIACAO (DDL)
-- 
-- Data Criacao ...........: 06/10/2019
-- Autor(es) ..............: Larissa Siqueira Sales
-- Banco de Dados .........: MySQL
-- Banco de Dados(nome) ...: detran
-- 
-- 
-- 
-- -----------------------------------------------------------------
use detran;

DROP TABLE telefone;
DROP TABLE INFRACAO;
DROP TABLE LOCAL;
DROP TABLE AGENTE;
DROP TABLE PROPRIETARIO;
DROP TABLE VEICULO;