-- --------     chatRevisaoP1    ------------
-- 
--         SCRIPT DE CRIACAO (DDL)
-- 
-- Data Criacao ...........: 12/10/2019
-- Autor(es) ..............: Larissa Siqueira Sales
-- Banco de Dados .........: MySQL
-- Banco de Dados (nome) ..: eleicao
-- 
-- ------------------------------------------

USE ELEICAO;

DROP TABLE registra;
DROP TABLE EFETIVACAO_CANDIDATO;
DROP TABLE JUSTIFICATIVA;
DROP TABLE VOTO;
DROP TABLE ELEITOR;