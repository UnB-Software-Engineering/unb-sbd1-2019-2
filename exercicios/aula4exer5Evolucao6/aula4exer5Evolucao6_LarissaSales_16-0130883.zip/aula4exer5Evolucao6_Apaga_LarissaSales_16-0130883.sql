-- --------  aula4exer5Evolucao6  ------------
-- 
--         SCRIPT DE CRIAÇÃO (DDL)
-- 
-- Data Criacao ...........: 14/10/2019
-- Autor(es) ..............: Larissa Siqueira Sales
-- Banco de Dados .........: MySQL
-- Banco de Dados(nome) ...: RECEITUARIO
-- 
-- PROJETO => 01 Base de Dados
--         => 06 Tabelas
-- 
-- -------------------------------------------

USE RECEITUARIO;

DROP TABLE medicamento;
DROP TABLE endereco;
DROP TABLE ESPECIALIDADE;
DROP TABLE RECEITA;
DROP TABLE PACIENTE;
DROP TABLE MEDICO;